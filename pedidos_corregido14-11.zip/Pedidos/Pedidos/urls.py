from django.contrib import admin
from django.urls import path, include
from mainApp import views

urlpatterns = [
    path('admin/', admin.site.urls),
    path('', views.home, name='home'),
    path('crear/', views.crear_pedido, name='crear_pedido'),
    path('detalle/<int:id>/', views.detalle_pedido, name='detalle_pedido'),
    path('editar/<int:id>/', views.editar_pedido, name='editar_pedido'),
    path('eliminar/<int:id>/', views.eliminar_pedido, name='eliminar_pedido'),
    path('mesa/<int:mesa_id>/pedidos/', views.pedidos_por_mesa, name='pedidos_por_mesa'),
]