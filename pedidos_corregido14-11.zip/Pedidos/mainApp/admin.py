from django.contrib import admin
from .models import Pedidos, Mesas

@admin.register(Pedidos)
class PedidosAdmin(admin.ModelAdmin):
    list_display = ['id', 'nombre', 'mesa', 'estado', 'fecha_creacion']
    list_filter = ['estado', 'fecha_creacion']
    search_fields = ['nombre', 'descripcion']

@admin.register(Mesas)
class MesasAdmin(admin.ModelAdmin):
    list_display = ['id', 'numero', 'ocupada', 'ubicacion']
    list_filter = ['ocupada']
    search_fields = ['numero', 'ubicacion']