from django.db import models
from django.db.models.signals import post_delete
from django.dispatch import receiver
from django.contrib.auth.models import User  # ✅ Importamos el modelo User

# Modelo de Mesas
class Mesas(models.Model):
    numero = models.CharField(max_length=10, unique=True, verbose_name="Número de Mesa")
    ocupada = models.BooleanField(default=False, verbose_name="Ocupada")
    ubicacion = models.CharField(max_length=100, verbose_name="Ubicación en el Restaurante")

    class Meta:
        verbose_name = "Mesa"
        verbose_name_plural = "Mesas"
        ordering = ['numero']

    def __str__(self):
        return f"Mesa {self.numero} - {'Ocupada' if self.ocupada else 'Libre'}"


# Modelo de Pedidos
class Pedidos(models.Model):
    ESTADO_CHOICES = [
        ('pendiente', 'Pendiente'),
        ('en_preparacion', 'En Preparación'),
        ('listo', 'Listo'),
        ('entregado', 'Entregado'),
    ]

    nombre = models.CharField(max_length=100, verbose_name="Nombre del Cliente")
    mesa = models.ForeignKey(Mesas, on_delete=models.CASCADE, verbose_name="Mesa")
    mesero = models.ForeignKey(User, on_delete=models.SET_NULL, null=True, verbose_name="Mesero")  # ✅ Nuevo campo
    descripcion = models.TextField(verbose_name="Descripción/Platos")
    estado = models.CharField(
        max_length=20,
        choices=ESTADO_CHOICES,
        default='pendiente',
        verbose_name="Estado"
    )
    fecha_creacion = models.DateTimeField(auto_now_add=True, verbose_name="Fecha de Creación")
    fecha_actualizacion = models.DateTimeField(auto_now=True, verbose_name="Última Actualización")

    class Meta:
        verbose_name = "Pedido"
        verbose_name_plural = "Pedidos"
        ordering = ['-fecha_creacion']

    def __str__(self):
        return f"Pedido #{self.id} - {self.nombre} - Mesa {self.mesa.numero} - Mesero {self.mesero.username if self.mesero else 'Sin asignar'}"


# ✅ Señal para liberar mesa cuando se elimina el pedido
@receiver(post_delete, sender=Pedidos)
def liberar_mesa(sender, instance, **kwargs):
    if instance.mesa:
        instance.mesa.ocupada = False
        instance.mesa.save()