from django.shortcuts import render, redirect, get_object_or_404
from django.contrib import messages
from .models import Pedidos, Mesas
from django.contrib.auth.models import User

# Página principal: lista de pedidos y mesas disponibles

def home(request):
    pedidos = Pedidos.objects.all()
    mesas_disponibles = Mesas.objects.filter(ocupada=False)
    meseros = User.objects.filter(groups__name='Meseros')  # ✅ solo usuarios del grupo Meseros
    return render(request, 'home.html', {'pedidos': pedidos, 'Mesas': mesas_disponibles, 'Meseros': meseros})
# Crear nuevo pedido
def crear_pedido(request):
    if request.method == 'POST':
        nombre = request.POST.get('nombre')
        mesa_id = request.POST.get('mesa')
        mesero_id = request.POST.get('mesero')
        descripcion = request.POST.get('descripcion')
        estado = request.POST.get('estado', 'pendiente')

        if nombre and mesa_id and mesero_id and descripcion:
            mesa = Mesas.objects.get(id=mesa_id)
            mesero = User.objects.get(id=mesero_id)

            mesa.ocupada = True
            mesa.save()

            Pedidos.objects.create(nombre=nombre, mesa=mesa, mesero=mesero, descripcion=descripcion, estado=estado)
            messages.success(request, '✅ ¡Pedido creado exitosamente!')
        else:
            messages.error(request, '❌ Todos los campos son obligatorios.')

    return redirect('home')
# Ver detalle del pedido
def detalle_pedido(request, id):
    pedido = get_object_or_404(Pedidos, id=id)
    return render(request, 'detalle_pedido.html', {'pedido': pedido})

# Editar pedido
def editar_pedido(request, id):
    pedido = get_object_or_404(Pedidos, id=id)
    # Mostrar mesas libres + la mesa actual
    mesas_disponibles = Mesas.objects.filter(ocupada=False) | Mesas.objects.filter(id=pedido.mesa.id)

    if request.method == 'POST':
        nombre = request.POST.get('nombre')
        mesa_id = request.POST.get('mesa')
        descripcion = request.POST.get('descripcion')
        estado = request.POST.get('estado')

        if nombre and mesa_id and descripcion:
            mesa_actual = pedido.mesa
            nueva_mesa = Mesas.objects.get(id=mesa_id)

            if mesa_actual.id != nueva_mesa.id:
                mesa_actual.ocupada = False
                mesa_actual.save()
                nueva_mesa.ocupada = True
                nueva_mesa.save()

            pedido.nombre = nombre
            pedido.mesa = nueva_mesa
            pedido.descripcion = descripcion
            pedido.estado = estado
            pedido.save()

            messages.success(request, '✅ ¡Pedido actualizado exitosamente!')
            return redirect('home')
        else:
            messages.error(request, '❌ Todos los campos son obligatorios.')

    return render(request, 'editar_pedido.html', {'pedido': pedido, 'Mesas': mesas_disponibles})
# Eliminar pedido
def eliminar_pedido(request, id):
    pedido = get_object_or_404(Pedidos, id=id)
    if request.method == 'POST':
        mesa = pedido.mesa
        mesa.ocupada = False
        mesa.save()
        pedido.delete()
        messages.success(request, '🗑️ Pedido eliminado y Mesa liberada.')
        return redirect('home')
    
    # ✅ Para GET, mostrar la página de confirmación
    return render(request, 'confirmar_eliminar.html', {'pedido': pedido})

# mostrar pedidos por mesa
def pedidos_por_mesa(request, mesa_id):
    mesa = get_object_or_404(Mesas, id=mesa_id)
    pedidos = Pedidos.objects.filter(mesa=mesa).exclude(estado='entregado')

    return render(request, 'pedidos_por_mesa.html', {
        'mesa': mesa,
        'pedidos': pedidos
    })