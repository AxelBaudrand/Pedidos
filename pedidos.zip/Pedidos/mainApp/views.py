from django.shortcuts import render, redirect, get_object_or_404
from django.contrib import messages
from .models import Pedidos

# READ - Listar todos los pedidos (página principal con CRUD integrado)
def home(request):
    pedidos = Pedidos.objects.all().order_by('-id')
    data = {'Pedidos': pedidos}
    return render(request, 'home.html', data)

# CREATE - Crear nuevo pedido (procesa el modal)
def crear_pedido(request):
    if request.method == 'POST':
        nombre = request.POST.get('nombre')
        mesa = request.POST.get('mesa')
        descripcion = request.POST.get('descripcion')
        estado = request.POST.get('estado', 'pendiente')
        
        if nombre and mesa and descripcion:
            Pedidos.objects.create(
                nombre=nombre,
                mesa=mesa,
                descripcion=descripcion,
                estado=estado
            )
            messages.success(request, '✅ ¡Pedido creado exitosamente!')
        else:
            messages.error(request, '❌ Todos los campos son obligatorios.')
    
    return redirect('home')

# READ - Ver detalle de un pedido (página separada)
def detalle_pedido(request, id):
    pedido = get_object_or_404(Pedidos, id=id)
    data = {'pedido': pedido}
    return render(request, 'detalle_pedido.html', data)

# UPDATE - Editar pedido existente (procesa el modal)
def editar_pedido(request, id):
    pedido = get_object_or_404(Pedidos, id=id)
    
    if request.method == 'POST':
        pedido.nombre = request.POST.get('nombre')
        pedido.mesa = request.POST.get('mesa')
        pedido.descripcion = request.POST.get('descripcion')
        pedido.estado = request.POST.get('estado')
        
        if pedido.nombre and pedido.mesa and pedido.descripcion:
            pedido.save()
            messages.success(request, '✅ ¡Pedido actualizado exitosamente!')
        else:
            messages.error(request, '❌ Todos los campos son obligatorios.')
    
    return redirect('home')

# DELETE - Eliminar pedido (muestra página de confirmación)
def eliminar_pedido(request, id):
    pedido = get_object_or_404(Pedidos, id=id)
    
    if request.method == 'POST':
        pedido.delete()
        messages.success(request, '✅ ¡Pedido eliminado exitosamente!')
        return redirect('home')
    
    # Si es GET, muestra la página de confirmación
    data = {'pedido': pedido}
    return render(request, 'confirmar_eliminar.html', data)